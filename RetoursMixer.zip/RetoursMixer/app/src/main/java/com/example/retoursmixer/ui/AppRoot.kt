package com.example.retoursmixer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.retoursmixer.MixerViewModel
import com.example.retoursmixer.Screen

@Composable
fun AppRoot(vm: MixerViewModel) {
    AppTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background,
        ) {
            val screen = vm.screen
            val lockedMixer = vm.lockedProfileId != null && screen is Screen.Mixer

            // En mode verrouillé, le bouton Retour ne fait rien.
            BackHandler(enabled = lockedMixer) { }
            BackHandler(enabled = !lockedMixer && screen !is Screen.Home) { vm.back() }

            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                when (screen) {
                    is Screen.Home -> HomeScreen(vm)
                    is Screen.Mixer -> {
                        val p = vm.profileById(screen.profileId)
                        if (p != null) MixerScreen(vm, p) else HomeScreen(vm)
                    }
                    is Screen.Editor -> ProfileEditorScreen(vm, screen.profileId)
                    is Screen.Settings -> SettingsScreen(vm)
                }
            }
        }
    }
}
