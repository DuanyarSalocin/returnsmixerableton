package com.example.retoursmixer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.retoursmixer.data.Profile
import com.example.retoursmixer.data.TrackUi

/** Dans Ableton, la valeur 0.85 du fader correspond à 0 dB (1.0 = +6 dB). */
const val ZERO_DB = 0.85f

/**
 * Fader vertical. Le glissement est RELATIF : toucher le fader ne fait jamais sauter le volume,
 * seul le déplacement du doigt le modifie (important pour des retours in-ear).
 */
@Composable
fun VerticalFader(
    value: Float,
    maxValue: Float,
    accent: Color,
    muted: Boolean,
    onChange: (Float) -> Unit,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val latestValue by rememberUpdatedState(value)
    val latestMax by rememberUpdatedState(maxValue)
    val latestOnChange by rememberUpdatedState(onChange)
    val latestOnFinished by rememberUpdatedState(onFinished)

    Canvas(
        modifier = modifier.pointerInput(Unit) {
            var dragValue = 0f
            val thumbHeightPx = 36.dp.toPx()
            detectVerticalDragGestures(
                onDragStart = { dragValue = latestValue },
                onDragEnd = { latestOnFinished() },
                onDragCancel = { latestOnFinished() },
                onVerticalDrag = { change, dragAmount ->
                    change.consume()
                    val travel = size.height - thumbHeightPx
                    if (travel > 0f) {
                        dragValue = (dragValue - dragAmount / travel).coerceIn(0f, latestMax)
                        latestOnChange(dragValue)
                    }
                },
            )
        }
    ) {
        val w = size.width
        val h = size.height
        val thumbH = 36.dp.toPx()
        val top = thumbH / 2f
        val bottom = h - thumbH / 2f
        val railW = 12.dp.toPx()
        val railX = (w - railW) / 2f
        val radius = CornerRadius(railW / 2f)

        fun yOf(v: Float): Float = bottom - (bottom - top) * v.coerceIn(0f, 1f)

        // Rail
        drawRoundRect(
            color = Color(0xFF2B2E37),
            topLeft = Offset(railX, top),
            size = Size(railW, bottom - top),
            cornerRadius = radius,
        )
        // Partie remplie
        val yv = yOf(value)
        drawRoundRect(
            color = if (muted) Color(0xFF6B6F7B) else accent.copy(alpha = 0.6f),
            topLeft = Offset(railX, yv),
            size = Size(railW, bottom - yv),
            cornerRadius = radius,
        )
        // Zone interdite au-dessus de la limite haute
        if (maxValue < 0.999f) {
            val ym = yOf(maxValue)
            drawRoundRect(
                color = Color(0xAA101114),
                topLeft = Offset(railX, top),
                size = Size(railW, ym - top),
                cornerRadius = radius,
            )
        }
        // Repères : le trait blanc épais = 0 dB
        for (mark in listOf(0.25f, 0.5f, 0.7f, 1f)) {
            val y = yOf(mark)
            drawLine(
                color = Color.White.copy(alpha = 0.25f),
                start = Offset(railX - 6.dp.toPx(), y),
                end = Offset(railX + railW + 6.dp.toPx(), y),
                strokeWidth = 1.dp.toPx(),
            )
        }
        val yz = yOf(ZERO_DB)
        drawLine(
            color = Color.White.copy(alpha = 0.75f),
            start = Offset(railX - 12.dp.toPx(), yz),
            end = Offset(railX + railW + 12.dp.toPx(), yz),
            strokeWidth = 2.dp.toPx(),
        )
        // Poignée
        val thumbW = minOf(w, 76.dp.toPx())
        val tx = (w - thumbW) / 2f
        val ty = yv - thumbH / 2f
        drawRoundRect(
            color = if (muted) Color(0xFF9A9EAB) else accent,
            topLeft = Offset(tx, ty),
            size = Size(thumbW, thumbH),
            cornerRadius = CornerRadius(8.dp.toPx()),
        )
        drawLine(
            color = Color(0xFF111111),
            start = Offset(tx + 10.dp.toPx(), ty + thumbH / 2f),
            end = Offset(tx + thumbW - 10.dp.toPx(), ty + thumbH / 2f),
            strokeWidth = 3.dp.toPx(),
        )
    }
}

/** Vumètre à segments. [level] est lu à l'intérieur du dessin : seul le dessin est rafraîchi. */
@Composable
fun LevelMeter(level: () -> Float, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val l = level().coerceIn(0f, 1f)
        drawRoundRect(
            color = Color(0xFF23262E),
            size = size,
            cornerRadius = CornerRadius(4.dp.toPx()),
        )
        val segments = 24
        val segH = size.height / segments
        val lit = (l * segments).toInt()
        for (s in 0 until lit) {
            val frac = (s + 1f) / segments
            val color = when {
                frac > ZERO_DB -> Color(0xFFEF5350)
                frac > 0.7f -> Color(0xFFFFEE58)
                else -> Color(0xFF66BB6A)
            }
            drawRect(
                color = color,
                topLeft = Offset(1.dp.toPx(), size.height - (s + 1) * segH + 1f),
                size = Size(size.width - 2.dp.toPx(), segH - 2f),
            )
        }
    }
}

@Composable
fun StripButton(
    label: String,
    active: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) activeColor else Color(0xFF2B2E37))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (active) Color(0xFF111111) else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
        )
    }
}

@Composable
fun ChannelStrip(
    track: TrackUi,
    profile: Profile,
    accent: Color,
    onVolume: (Float) -> Unit,
    onVolumeEnd: () -> Unit,
    onMute: () -> Unit,
    onSolo: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .padding(horizontal = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = track.name,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            fontSize = 13.sp,
            lineHeight = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp),
        )
        Spacer(Modifier.height(8.dp))

        if (profile.showMute) {
            StripButton("M", track.mute, Color(0xFFFFB74D), onMute)
            Spacer(Modifier.height(6.dp))
        }
        if (profile.showSolo) {
            StripButton("S", track.solo, Color(0xFF4FC3F7), onSolo)
            Spacer(Modifier.height(6.dp))
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            VerticalFader(
                value = track.volume,
                maxValue = profile.maxVolume,
                accent = accent,
                muted = track.mute,
                onChange = onVolume,
                onFinished = onVolumeEnd,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
            )
            if (profile.showMeters) {
                LevelMeter(
                    level = { track.level },
                    modifier = Modifier
                        .width(12.dp)
                        .fillMaxHeight(),
                )
            }
        }
    }
}
