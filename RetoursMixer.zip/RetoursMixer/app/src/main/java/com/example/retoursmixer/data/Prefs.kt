package com.example.retoursmixer.data

import android.content.Context

/** Stockage local (SharedPreferences) : connexion, profils, profil verrouillé. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("retours_live", Context.MODE_PRIVATE)

    var host: String
        get() = sp.getString("host", "192.168.1.10") ?: "192.168.1.10"
        set(v) = sp.edit().putString("host", v).apply()

    var sendPort: Int
        get() = sp.getInt("sendPort", 11000)
        set(v) = sp.edit().putInt("sendPort", v).apply()

    var listenPort: Int
        get() = sp.getInt("listenPort", 11001)
        set(v) = sp.edit().putInt("listenPort", v).apply()

    var lockedProfileId: String?
        get() = sp.getString("lockedProfileId", null)
        set(v) = sp.edit().putString("lockedProfileId", v).apply()

    fun loadProfiles(): List<Profile> {
        val raw = sp.getString("profiles", null) ?: return defaultProfiles()
        return try {
            profilesFromJson(raw).ifEmpty { defaultProfiles() }
        } catch (e: Exception) {
            defaultProfiles()
        }
    }

    fun saveProfiles(list: List<Profile>) {
        sp.edit().putString("profiles", profilesToJson(list)).apply()
    }
}
