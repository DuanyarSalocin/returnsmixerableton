package com.example.retoursmixer

sealed interface Screen {
    data object Home : Screen
    data class Mixer(val profileId: String) : Screen

    /** profileId == null : création d'un nouveau profil. */
    data class Editor(val profileId: String?) : Screen
    data object Settings : Screen
}
