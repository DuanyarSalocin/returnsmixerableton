package com.example.retoursmixer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val ProfileColors = listOf(
    Color(0xFF4FC3F7), // bleu
    Color(0xFFFFB74D), // orange
    Color(0xFF81C784), // vert
    Color(0xFFE57373), // rouge
    Color(0xFFBA68C8), // violet
    Color(0xFFFFF176), // jaune
)

fun profileColor(index: Int): Color =
    ProfileColors[((index % ProfileColors.size) + ProfileColors.size) % ProfileColors.size]

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(0xFF4FC3F7),
        onPrimary = Color(0xFF00212E),
        background = Color(0xFF101114),
        onBackground = Color(0xFFE6E6EA),
        surface = Color(0xFF1A1C21),
        onSurface = Color(0xFFE6E6EA),
        surfaceVariant = Color(0xFF262932),
        onSurfaceVariant = Color(0xFFB4B7C2),
        error = Color(0xFFFF6B6B),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun ConnectionBadge(connected: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Spacer(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (connected) Color(0xFF66BB6A) else Color(0xFFEF5350))
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = if (connected) "Ableton" else "Hors ligne",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
