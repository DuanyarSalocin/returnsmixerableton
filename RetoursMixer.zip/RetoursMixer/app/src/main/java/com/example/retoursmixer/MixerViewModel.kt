package com.example.retoursmixer

import android.app.Application
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.retoursmixer.data.Prefs
import com.example.retoursmixer.data.Profile
import com.example.retoursmixer.data.TrackUi
import com.example.retoursmixer.data.profilesFromJson
import com.example.retoursmixer.data.profilesToJson
import com.example.retoursmixer.osc.OscClient
import com.example.retoursmixer.osc.OscMessage
import com.example.retoursmixer.osc.asBool
import com.example.retoursmixer.osc.asFloat
import com.example.retoursmixer.osc.asInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Cerveau de l'appli : parle à AbletonOSC, garde la liste des pistes à jour
 * et gère les profils.
 *
 * Choix de conception : au lieu d'abonnements (start_listen), l'appli INTERROGE Ableton
 * uniquement pour les pistes affichées à l'écran (vumètres ~10 Hz, volume/mute 2 Hz).
 * Les réponses d'AbletonOSC sont renvoyées à l'IP qui a posé la question : chaque téléphone
 * reçoit donc ses propres réponses, même quand plusieurs musiciens sont connectés en même temps.
 */
class MixerViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val client = OscClient(viewModelScope)

    // ---------- État observable par l'interface ----------

    var tracks by mutableStateOf<List<TrackUi>>(emptyList())
        private set

    var connected by mutableStateOf(false)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var profiles by mutableStateOf(prefs.loadProfiles())
        private set

    var host by mutableStateOf(prefs.host)
        private set

    var sendPort by mutableIntStateOf(prefs.sendPort)
        private set

    var listenPort by mutableIntStateOf(prefs.listenPort)
        private set

    var lockedProfileId by mutableStateOf(prefs.lockedProfileId)
        private set

    var screen by mutableStateOf<Screen>(
        prefs.lockedProfileId
            ?.let { id -> if (profiles.any { it.id == id }) Screen.Mixer(id) else null }
            ?: Screen.Home
    )
        private set

    // ---------- État interne ----------

    private val backStack = ArrayDeque<Screen>()
    private var active = false
    private var lastRx = 0L
    private val visible = HashMap<Int, Int>() // index de piste -> nombre d'écrans qui l'affichent
    private val pendingVolumes = LinkedHashMap<Int, Float>()

    init {
        viewModelScope.launch { client.incoming.collect { handle(it) } }
        viewModelScope.launch { client.errors.collect { errorMessage = it } }
        startLoops()
    }

    // ---------- Cycle de vie ----------

    /** Appelé par l'activité : on coupe le réseau quand l'appli n'est plus visible. */
    fun onForeground(on: Boolean) {
        active = on
        if (on) {
            connect()
        } else {
            client.stop()
            connected = false
        }
    }

    private fun connect() {
        client.start(host, sendPort, listenPort)
        pollStructure()
        for (i in visible.keys.toList()) queryValues(i)
    }

    override fun onCleared() {
        client.stop()
    }

    // ---------- Boucles d'interrogation ----------

    private fun startLoops() {
        // Envoi groupé des mouvements de fader (une fois toutes les 30 ms au maximum par piste).
        viewModelScope.launch {
            while (isActive) {
                delay(30)
                flushVolumes()
            }
        }
        // Vumètres : 10 Hz sur les pistes affichées.
        viewModelScope.launch {
            while (isActive) {
                delay(100)
                if (active) {
                    for (i in visible.keys.toList()) client.send("/live/track/get/output_meter_level", i)
                }
                decayMeters()
            }
        }
        // Volume / mute : 2 Hz. Structure des pistes : toutes les 3 s.
        viewModelScope.launch {
            var tick = 0
            while (isActive) {
                delay(500)
                if (!active) continue
                for (i in visible.keys.toList()) queryValues(i)
                connected = SystemClock.uptimeMillis() - lastRx < 7000
                tick++
                if (tick % 6 == 0) pollStructure()
            }
        }
    }

    private fun queryValues(i: Int) {
        client.send("/live/track/get/volume", i)
        client.send("/live/track/get/mute", i)
    }

    private fun queryFlags() {
        for (t in tracks) {
            client.send("/live/track/get/is_foldable", t.index)
            client.send("/live/track/get/is_grouped", t.index)
        }
    }

    private fun pollStructure() {
        client.send("/live/song/get/track_names")
        queryFlags()
    }

    private fun decayMeters() {
        val now = SystemClock.uptimeMillis()
        for (t in tracks) {
            if (t.level > 0f && now - t.levelAt > 400) {
                t.level = if (t.level < 0.01f) 0f else t.level * 0.85f
            }
        }
    }

    // ---------- Messages reçus d'Ableton ----------

    private inline fun withTrack(args: List<Any?>, block: (TrackUi) -> Unit) {
        val idx = args.getOrNull(0).asInt() ?: return
        val t = tracks.getOrNull(idx) ?: return
        block(t)
    }

    private fun handle(m: OscMessage) {
        val now = SystemClock.uptimeMillis()
        lastRx = now
        if (!connected) connected = true
        if (errorMessage != null) errorMessage = null

        val a = m.args
        when (m.address) {
            "/live/song/get/track_names" -> onTrackNames(a.map { it?.toString() ?: "" })

            "/live/track/get/volume" -> withTrack(a) { t ->
                val v = a.getOrNull(1).asFloat()
                if (v != null && now - t.touchedVolumeAt > HOLD_MS) t.volume = v.coerceIn(0f, 1f)
            }

            "/live/track/get/mute" -> withTrack(a) { t ->
                val v = a.getOrNull(1).asBool()
                if (v != null && now - t.touchedMuteAt > HOLD_MS) t.mute = v
            }

            "/live/track/get/output_meter_level" -> withTrack(a) { t ->
                var lvl = 0f
                for (i in 1 until a.size) lvl = maxOf(lvl, a[i].asFloat() ?: 0f)
                lvl = lvl.coerceIn(0f, 1f)
                // Montée immédiate, descente rapide mais lissée.
                t.level = if (lvl >= t.level) lvl else (t.level + lvl) / 2f
                t.levelAt = now
            }

            "/live/track/get/is_foldable" -> withTrack(a) { it.isGroup = a.getOrNull(1).asBool() ?: false }

            "/live/track/get/is_grouped" -> withTrack(a) { it.isGrouped = a.getOrNull(1).asBool() ?: false }

            "/live/error" -> errorMessage = a.joinToString(" ")
        }
    }

    private fun onTrackNames(names: List<String>) {
        val old = tracks
        if (old.size == names.size) {
            names.forEachIndexed { i, n -> if (old[i].name != n) old[i].name = n }
        } else {
            // Pistes ajoutées / supprimées : on reconstruit tout et on relit l'état.
            tracks = names.mapIndexed { i, n -> TrackUi(i, n) }
            queryFlags()
            for (i in visible.keys.toList()) queryValues(i)
        }
    }

    // ---------- Actions de l'interface : pistes ----------

    /** Une piste devient visible à l'écran : on commence à l'interroger. */
    fun trackShown(index: Int) {
        visible[index] = (visible[index] ?: 0) + 1
        queryValues(index)
    }

    fun trackHidden(index: Int) {
        val c = (visible[index] ?: 0) - 1
        if (c <= 0) visible.remove(index) else visible[index] = c
    }

    fun setVolume(t: TrackUi, v: Float) {
        val c = v.coerceIn(0f, 1f)
        t.volume = c
        t.touchedVolumeAt = SystemClock.uptimeMillis()
        pendingVolumes[t.index] = c
    }

    fun volumeGestureEnd(t: TrackUi) {
        t.touchedVolumeAt = SystemClock.uptimeMillis()
        flushVolumes()
    }

    private fun flushVolumes() {
        if (pendingVolumes.isEmpty()) return
        val copy = LinkedHashMap(pendingVolumes)
        pendingVolumes.clear()
        for ((i, v) in copy) client.send("/live/track/set/volume", i, v)
    }

    fun toggleMute(t: TrackUi) {
        val v = !t.mute
        t.mute = v
        t.touchedMuteAt = SystemClock.uptimeMillis()
        client.send("/live/track/set/mute", t.index, if (v) 1 else 0)
    }

    // ---------- Actions de l'interface : navigation ----------

    fun go(s: Screen) {
        if (s != screen) backStack.addLast(screen)
        screen = s
    }

    /** Revient à l'écran précédent (vraie pile de navigation). */
    fun back() {
        screen = backStack.removeLastOrNull() ?: Screen.Home
    }

    fun goHome() {
        backStack.clear()
        screen = Screen.Home
    }

    fun lockOn(profileId: String) {
        prefs.lockedProfileId = profileId
        lockedProfileId = profileId
    }

    fun unlock() {
        prefs.lockedProfileId = null
        lockedProfileId = null
        goHome()
    }

    // ---------- Actions de l'interface : profils ----------

    fun profileById(id: String?): Profile? = profiles.firstOrNull { it.id == id }

    fun saveProfile(p: Profile) {
        profiles = if (profiles.any { it.id == p.id }) {
            profiles.map { if (it.id == p.id) p else it }
        } else {
            profiles + p
        }
        prefs.saveProfiles(profiles)
    }

    fun deleteProfile(id: String) {
        profiles = profiles.filter { it.id != id }
        prefs.saveProfiles(profiles)
        if (lockedProfileId == id) unlock()
    }

    fun exportProfiles(): String = profilesToJson(profiles)

    /** Fusionne (par id) des profils au format JSON. Renvoie false si le texte est invalide. */
    fun importProfiles(json: String): Boolean {
        return try {
            val imported = profilesFromJson(json.trim())
            if (imported.isEmpty()) return false
            val byId = LinkedHashMap<String, Profile>()
            profiles.forEach { byId[it.id] = it }
            imported.forEach { byId[it.id] = it }
            profiles = byId.values.toList()
            prefs.saveProfiles(profiles)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- Actions de l'interface : réglages ----------

    fun applySettings(newHost: String, newSendPort: Int, newListenPort: Int) {
        host = newHost.trim()
        sendPort = newSendPort
        listenPort = newListenPort
        prefs.host = host
        prefs.sendPort = sendPort
        prefs.listenPort = listenPort
        errorMessage = null
        connected = false
        tracks = emptyList()
        if (active) connect()
    }

    private companion object {
        /** Après un geste local, on ignore les réponses d'Ableton pendant ce délai (ms). */
        const val HOLD_MS = 700L
    }
}
