package com.example.retoursmixer.osc

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.net.SocketException

/**
 * Client OSC en UDP : envoie vers Ableton (port 11000 par défaut) et écoute
 * les réponses sur un port local (11001 par défaut, imposé par AbletonOSC).
 * Tout le réseau passe par Dispatchers.IO (interdit sur le thread principal).
 */
class OscClient(private val scope: CoroutineScope) {

    private val _incoming = MutableSharedFlow<OscMessage>(
        extraBufferCapacity = 2048,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val incoming: SharedFlow<OscMessage> = _incoming

    private val _errors = MutableSharedFlow<String>(
        extraBufferCapacity = 8,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val errors: SharedFlow<String> = _errors

    private var job: Job? = null
    private var socket: DatagramSocket? = null
    private var outbox: Channel<ByteArray> = Channel(Channel.UNLIMITED)

    @Synchronized
    fun start(host: String, sendPort: Int, listenPort: Int) {
        stop()
        val box = Channel<ByteArray>(Channel.UNLIMITED)
        outbox = box

        job = scope.launch(Dispatchers.IO) {
            var sock: DatagramSocket? = null
            try {
                val target = InetSocketAddress(InetAddress.getByName(host), sendPort)
                val s = DatagramSocket(null as SocketAddress?)
                s.reuseAddress = true
                s.bind(InetSocketAddress(listenPort))
                sock = s
                socket = s

                launch { receiveLoop(s) }

                for (bytes in box) {
                    try {
                        s.send(DatagramPacket(bytes, bytes.size, target))
                    } catch (e: Exception) {
                        if (s.isClosed) break
                        _errors.tryEmit(e.message ?: e.javaClass.simpleName)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _errors.tryEmit(e.message ?: e.javaClass.simpleName)
            } finally {
                sock?.close()
            }
        }
    }

    private fun receiveLoop(sock: DatagramSocket) {
        val buf = ByteArray(16384)
        val packet = DatagramPacket(buf, buf.size)
        while (!sock.isClosed) {
            try {
                packet.length = buf.size
                sock.receive(packet)
                for (m in Osc.decode(buf, packet.length)) {
                    _incoming.tryEmit(m)
                }
            } catch (e: SocketException) {
                break // socket fermé par stop()
            } catch (e: Exception) {
                _errors.tryEmit(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        try {
            socket?.close()
        } catch (e: Exception) {
        }
        socket = null
        outbox.close()
    }

    /** Envoie un message OSC (arguments : Int, Float ou String). Non bloquant. */
    fun send(address: String, vararg args: Any?) {
        try {
            outbox.trySend(Osc.encode(address, args.toList()))
        } catch (e: Exception) {
        }
    }
}
