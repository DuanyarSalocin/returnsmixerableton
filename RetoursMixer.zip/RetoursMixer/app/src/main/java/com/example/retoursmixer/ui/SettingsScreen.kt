package com.example.retoursmixer.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.retoursmixer.MixerViewModel

@Composable
fun SettingsScreen(vm: MixerViewModel) {
    val ctx = LocalContext.current
    var host by remember { mutableStateOf(vm.host) }
    var send by remember { mutableStateOf(vm.sendPort.toString()) }
    var listen by remember { mutableStateOf(vm.listenPort.toString()) }
    var info by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.back() }) { Text("‹ Retour") }
            Text("Réglages", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Text("Connexion à Ableton", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        OutlinedTextField(
            value = host,
            onValueChange = { host = it },
            label = { Text("Adresse IP de l'ordinateur (ex. 192.168.1.20)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = send,
            onValueChange = { send = it.filter(Char::isDigit) },
            label = { Text("Port d'envoi (AbletonOSC : 11000)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = listen,
            onValueChange = { listen = it.filter(Char::isDigit) },
            label = { Text("Port d'écoute sur ce téléphone (AbletonOSC : 11001)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            onClick = {
                vm.applySettings(host, send.toIntOrNull() ?: 11000, listen.toIntOrNull() ?: 11001)
                info = "Réglages appliqués, reconnexion en cours."
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Appliquer et se reconnecter") }

        Text(
            text = if (vm.connected) "✔ Ableton répond." else "✖ Aucune réponse d'Ableton pour le moment.",
            color = if (vm.connected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        vm.errorMessage?.let {
            Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
        }

        HorizontalDivider()

        Text("Profils : copier vers un autre téléphone", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Configure les profils une fois, copie-les, envoie le texte (message, mail…) aux musiciens, " +
                "puis « Importer » sur leur téléphone.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("profils", vm.exportProfiles()))
                    info = "Profils copiés dans le presse-papiers."
                },
                modifier = Modifier.weight(1f),
            ) { Text("Copier") }
            OutlinedButton(
                onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val text = cm.primaryClip
                        ?.takeIf { it.itemCount > 0 }
                        ?.getItemAt(0)
                        ?.coerceToText(ctx)
                        ?.toString()
                    info = if (text != null && vm.importProfiles(text)) {
                        "Profils importés."
                    } else {
                        "Le presse-papiers ne contient pas de profils valides."
                    }
                },
                modifier = Modifier.weight(1f),
            ) { Text("Importer") }
        }
        info?.let { Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary) }
    }
}
